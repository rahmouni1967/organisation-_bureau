# 🔁 Cycle Semaine 2 – Chantier

- [ ] Vérifier secteur A
- [ ] Prendre notes terrain
- [ ] Suivi des ouvriers