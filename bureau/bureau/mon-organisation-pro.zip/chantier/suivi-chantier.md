# 🧱 Suivi du chantier

### Points à vérifier :
- Avancement des travaux
- Livraison des matériaux
- Sécurité du site