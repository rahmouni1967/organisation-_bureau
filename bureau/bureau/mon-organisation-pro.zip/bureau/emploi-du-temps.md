# 🧑‍💻 Emploi du temps – Bureau (3h/jour)

## Horaire : 08h00 – 11h00

### Tâches types :
- Révision du planning
- Classement administratif
- Réponse aux e-mails
- Mise à jour Plane / Joplin