# 📋 Cycle Semaine 1 – Bureau

- [ ] Trier documents
- [ ] Planifier la semaine
- [ ] Créer ou mettre à jour les documents