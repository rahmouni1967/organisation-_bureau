# 📝 Résumé organisation

Utilisation de Joplin + Plane pour gérer travail, bureau et chantier.