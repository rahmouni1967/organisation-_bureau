# ✅ Modèle de tâches Joplin

- [ ] Planifier la semaine
- [ ] Organiser documents
- [ ] Créer cycle Plane