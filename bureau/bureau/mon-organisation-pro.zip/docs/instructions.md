# 📘 Guide d'utilisation

1. Travailler le matin au bureau
2. Suivre les tâches sur Plane
3. Noter les résultats dans Joplin